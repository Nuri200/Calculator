/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Nuri Astutik
 */
public class hitung {
    public int getPenjumlahan(int angka1 , int angka2){
        int hasil_tambah = angka1 + angka2;
        return hasil_tambah;
    }
    
    public int getPengurangan(int angka1 , int angka2){
        int hasil_kurang = angka1 - angka2;
        return hasil_kurang;
    }
    
    public int getPerkalian(int angka1 , int angka2){
        int hasil_kali = angka1 * angka2;
        return hasil_kali;
    }
    
    public int getPembagian(int angka1 , int angka2){
        int hasil_bagi = angka1 / angka2;
        return hasil_bagi;
    }
}
